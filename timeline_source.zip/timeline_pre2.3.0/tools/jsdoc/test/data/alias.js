/** 
 * Twiddle the given flick. 
 * @name twiddle.flick
 */
function zipZap(zID) { // <-- this is NOT the named object above!
}

/** 
 * Join two str together. 
 * @name Concat
 * @function
 * @param strX
 * @param strY
 */
 