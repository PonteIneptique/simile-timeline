
/**
 * @param { String ,    Array } [id] Specifies the id, if applicable.
 */
function Document(id){

	this.publish = function(
		source,
		format,
		target
	)
	{}

}
