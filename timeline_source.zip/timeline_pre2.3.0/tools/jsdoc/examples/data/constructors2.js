﻿/**
 * A collection of records.
 * @constructor
 */
function RecordSet() {
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "CONSTRUCTOR",
                desc: "A collection of records.",
                alias: "RecordSet",
                memberof: "",
                params: [],
                methods: [],
                name: "RecordSet"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples/data/constructors2.js",
            memberof: "",
            params: [],
            methods: [],
            name: "examples/data/constructors2.js"
        }
    }
]
*/