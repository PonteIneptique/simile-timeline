framework.createClass(
    "FileWatcher.Widget",
    /** @scope FileWatcher.Widget */
    {
        /** Set up the widget. */
        initialize: function(container, args) {
        }
    }
);

var Record = new function() {
    return /** @scope Record */ {
        getRecord: function() {}
    };
}

/*
[
    {
        symbols: [
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "Set up the widget.",
                alias: "FileWatcher.Widget.initialize"
                memberof: "",
                params: [
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "container",
                        isOptional: false
                    },
                    {
                        title: "param",
                        desc: "",
                        type: "",
                        name: "args",
                        isOptional: false
                    }
                ],
                methods: [],
                name: "FileWatcher.Widget.initialize"
            },
            {
                doc: { tags: [] },
                returns: [],
                type: "",
                properties: [],
                isa: "FUNCTION",
                desc: "undocumented",
                alias: "Record.getRecord",
                memberof: "",
                params: [],
                methods: [],
                name: "Record.getRecord"
            }
        ],
        overview: {
            doc: { tags: [] },
            returns: [],
            type: "",
            properties: [],
            isa: "FILE",
            desc: "No overview provided.",
            alias: "examples\data\namespace.js",
            memberof: "",
            params: [],
            methods: [],
            name: "namespace.js"
        }
    }
]
*/